import React from "react";
import Product from "./Product";

const Products = ({product , productQuantity, updateQuantity , addToCart , openModal}) => (
 
<Product
            key={product.id}
            price={product.price}
            name={product.name}
            image={product.image}
            id={product.id}
            productQuantity={productQuantity}
            updateQuantity={updateQuantity}
            addToCart = {addToCart}
            openModal={openModal}
          />
)

export default Products;
