import React, {Component} from 'react'

class RadioButton extends Component{
    render(){
        return(
            <div >
            <input type="radio" id="f-option" name="selector"/>
            <label for="f-option">Low-High</label>
            <br/>
            <input type="radio" id="s-option" name="selector"/>
            <label for="s-option">High-Low</label>
            </div>
        )
    }
}

export default RadioButton;