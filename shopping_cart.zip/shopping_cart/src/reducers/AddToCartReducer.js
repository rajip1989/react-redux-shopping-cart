

export const addProductsToCartReducer = (state = [],action) => {
    switch(action.type){
        case "ADD_TO_CART" : {
            return [action.noOfItems, action.totalAmount]
        }
        // case "RESET_ACTION": {
        //     //return  [...state, action.payLoad]
        //     return action.payLoad
        // }
        default :
        return state
    }
}

export default addProductsToCartReducer;
