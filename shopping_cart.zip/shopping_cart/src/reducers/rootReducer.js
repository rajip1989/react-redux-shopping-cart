import {getProductsReducer} from "./ProductsReducer"
import { searchProductsReducer} from "./SearchReducer"
import {addProductsToCartReducer} from "./AddToCartReducer"
import {combineReducers} from "redux";

const rootReducer = combineReducers({
    getProductsReducer,
    searchProductsReducer,
    addProductsToCartReducer
  })

export default rootReducer;